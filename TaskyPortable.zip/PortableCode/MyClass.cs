﻿using System;

namespace PortableCode
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

